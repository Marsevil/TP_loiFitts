/****************************************************************************
** Meta object code from reading C++ file 'configview.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../NewFitts/Views/configview.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'configview.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ConfigView_t {
    QByteArrayData data[17];
    char stringdata0[154];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ConfigView_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ConfigView_t qt_meta_stringdata_ConfigView = {
    {
QT_MOC_LITERAL(0, 0, 10), // "ConfigView"
QT_MOC_LITERAL(1, 11, 7), // "confirm"
QT_MOC_LITERAL(2, 19, 0), // ""
QT_MOC_LITERAL(3, 20, 6), // "Config"
QT_MOC_LITERAL(4, 27, 6), // "cancel"
QT_MOC_LITERAL(5, 34, 7), // "updateA"
QT_MOC_LITERAL(6, 42, 2), // "_a"
QT_MOC_LITERAL(7, 45, 7), // "updateB"
QT_MOC_LITERAL(8, 53, 2), // "_b"
QT_MOC_LITERAL(9, 56, 13), // "updateMinSize"
QT_MOC_LITERAL(10, 70, 8), // "_minSize"
QT_MOC_LITERAL(11, 79, 13), // "updateMaxSize"
QT_MOC_LITERAL(12, 93, 8), // "_maxSize"
QT_MOC_LITERAL(13, 102, 13), // "updateNbPoint"
QT_MOC_LITERAL(14, 116, 8), // "_nbPoint"
QT_MOC_LITERAL(15, 125, 13), // "cancelPressed"
QT_MOC_LITERAL(16, 139, 14) // "confirmPressed"

    },
    "ConfigView\0confirm\0\0Config\0cancel\0"
    "updateA\0_a\0updateB\0_b\0updateMinSize\0"
    "_minSize\0updateMaxSize\0_maxSize\0"
    "updateNbPoint\0_nbPoint\0cancelPressed\0"
    "confirmPressed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ConfigView[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       4,    0,   62,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   63,    2, 0x08 /* Private */,
       7,    1,   66,    2, 0x08 /* Private */,
       9,    1,   69,    2, 0x08 /* Private */,
      11,    1,   72,    2, 0x08 /* Private */,
      13,    1,   75,    2, 0x08 /* Private */,
      15,    0,   78,    2, 0x08 /* Private */,
      16,    0,   79,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    2,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void ConfigView::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ConfigView *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->confirm((*reinterpret_cast< Config(*)>(_a[1]))); break;
        case 1: _t->cancel(); break;
        case 2: _t->updateA((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->updateB((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 4: _t->updateMinSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->updateMaxSize((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->updateNbPoint((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->cancelPressed(); break;
        case 8: _t->confirmPressed(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ConfigView::*)(Config ) const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ConfigView::confirm)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ConfigView::*)() const;
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&ConfigView::cancel)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject ConfigView::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_ConfigView.data,
    qt_meta_data_ConfigView,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ConfigView::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ConfigView::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ConfigView.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int ConfigView::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void ConfigView::confirm(Config _t1)const
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(const_cast< ConfigView *>(this), &staticMetaObject, 0, _a);
}

// SIGNAL 1
void ConfigView::cancel()const
{
    QMetaObject::activate(const_cast< ConfigView *>(this), &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
